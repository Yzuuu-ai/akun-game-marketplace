const gameAccounts = [
  {
    id: 1,
    namaGame: "Mobile Legends",
    harga: 500000,
    deskripsi: "Rank Mythic, 80 hero, 100 skin",
    image: "/assets/ml.jpg",
    username: "player_ml"
  },
  {
    id: 2,
    namaGame: "PUBG Mobile",
    harga: 450000,
    deskripsi: "Level 70, banyak skin senjata",
    image: "/assets/pubg.jpg",
    username: "player_pubg"
  }
];

export default gameAccounts;