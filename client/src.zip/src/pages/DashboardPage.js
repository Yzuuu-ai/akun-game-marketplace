import { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AccountContext } from '../Context/AccountContext';

const DashboardPage = () => {
  const { accounts } = useContext(AccountContext);
  const navigate = useNavigate();
  const walletAddress = localStorage.getItem("wallet");

  const shortenAddress = (addr) =>
    addr ? addr.slice(0, 6) + "..." + addr.slice(-4) : "";

  // Format harga ke IDR
  const formatHarga = (harga) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(harga);
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
      <p className="mb-2">Wallet: {shortenAddress(walletAddress)}</p>

      <button
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-6"
        onClick={() => navigate("/tambah-akun")}
      >
        Tambah Akun Game
      </button>

      <h2 className="text-xl font-semibold mb-4">Akun yang Kamu Jual</h2>
      
      {accounts.length === 0 ? (
        <p>(Belum ada akun terdaftar)</p>
      ) : (
        <ul className="space-y-2">
          {accounts.map((acc) => (
            <li key={acc.id} className="border p-4 rounded-lg shadow">
              <p><strong>Game:</strong> {acc.namaGame}</p>
              <p><strong>Username:</strong> {acc.username}</p>
              {acc.rank && <p><strong>Rank:</strong> {acc.rank}</p>}
              <p><strong>Harga:</strong> {formatHarga(acc.harga)}</p>
              {acc.deskripsi && <p className="mt-2 text-gray-600">{acc.deskripsi}</p>}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default DashboardPage;