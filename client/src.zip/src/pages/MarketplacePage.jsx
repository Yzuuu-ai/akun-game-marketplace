import React, { useState, useContext } from 'react';
import { AccountContext } from '../Context/AccountContext';
import Navbar from '../components/Navbar';

const MarketplacePage = () => {
  const { accounts } = useContext(AccountContext);
  const [searchTerm, setSearchTerm] = useState('');

  // Format harga ke IDR
  const formatHarga = (harga) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(harga);
  };

  // Filter akun berdasarkan nama game atau username
  const filteredAccounts = accounts.filter(account => 
    account.namaGame.toLowerCase().includes(searchTerm.toLowerCase()) ||
    account.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-10 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-2xl font-bold mb-3">Marketplace Akun Game</h1>
          <p className="mb-5">
            Temukan akun game premium dengan harga terbaik
          </p>
          
          <div className="max-w-xl mx-auto">
            <div className="relative">
              <input
                type="text"
                placeholder="Cari game atau username..."
                className="w-full px-4 py-2 pl-10 rounded-lg bg-white bg-opacity-20 backdrop-blur-sm text-white placeholder-white placeholder-opacity-70 focus:outline-none focus:ring-1 focus:ring-white"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-4 w-4 absolute left-3 top-2.5 text-white opacity-70" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Daftar Akun */}
      <div className="max-w-6xl mx-auto py-6 px-4">
        <div className="mb-5">
          <h2 className="text-lg font-semibold text-gray-700">
            {filteredAccounts.length} Akun Tersedia
          </h2>
        </div>

        {filteredAccounts.length === 0 ? (
          <div className="text-center py-8 bg-white rounded-lg shadow-sm">
            <div className="bg-gray-200 border-2 border-dashed rounded-xl w-12 h-12 mx-auto mb-3" />
            <h3 className="text-md font-medium text-gray-800 mb-1">Tidak ada akun yang ditemukan</h3>
            <p className="text-gray-500 text-sm mb-3">
              Coba kata kunci lain atau periksa kembali nanti
            </p>
            <button 
              className="text-blue-600 text-sm hover:text-blue-800"
              onClick={() => setSearchTerm('')}
            >
              Tampilkan Semua Akun
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredAccounts.map((account) => (
              <div 
                key={account.id} 
                className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100 hover:shadow-md transition-shadow"
              >
                <div className="h-40 overflow-hidden">
                  <img 
                    src={account.image || "https://placehold.co/600x400/e2e8f0/cbd5e1?text=Game+Account"} 
                    alt={account.namaGame} 
                    className="w-full h-full object-cover"
                  />
                </div>
                
                <div className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-semibold text-gray-800">{account.namaGame}</h3>
                    <span className="bg-blue-50 text-blue-700 text-xs font-medium px-2 py-1 rounded">
                      {account.rank || 'Pro'}
                    </span>
                  </div>
                  
                  <div className="space-y-2 mb-3">
                    <div className="flex items-center text-sm">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-500 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                      <span className="text-gray-600">@{account.username}</span>
                    </div>
                    
                    <div className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-500 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span className="font-bold text-green-600">{formatHarga(account.harga)}</span>
                    </div>
                    
                    {account.deskripsi && (
                      <p className="text-gray-500 text-xs mt-1">
                        {account.deskripsi}
                      </p>
                    )}
                  </div>
                  
                  <button className="w-full py-2 bg-gradient-to-r from-blue-500 to-blue-600 text-white text-sm font-medium rounded-md hover:from-blue-600 hover:to-blue-700 transition-all">
                    Beli Sekarang
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MarketplacePage;