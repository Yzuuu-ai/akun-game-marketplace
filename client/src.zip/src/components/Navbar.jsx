import React from "react";
import { Link, useLocation } from "react-router-dom";

const Navbar = () => {
  const location = useLocation();

  // Sembunyikan navbar di halaman login
  if (location.pathname === "/login") return null;

  return (
    <nav className="bg-white shadow-md p-4 flex justify-between items-center">
      <Link to="/" className="text-xl font-bold text-blue-600">
        GameMarket
      </Link>
      <div className="space-x-4">
        <Link to="/dashboard" className="text-gray-700 hover:text-blue-600">
          Dashboard
        </Link>
        <Link to="/tambah-akun" className="text-gray-700 hover:text-blue-600">
          Tambah Akun
        </Link>
        <Link to="/marketplace" className="text-gray-700 hover:text-blue-600">
          Marketplace
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;